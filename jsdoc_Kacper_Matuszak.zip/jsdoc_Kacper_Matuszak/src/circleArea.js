/**
* @author Kacper Matuszak 5D
 * @param {number} radius
 * @throws {Error} if radius is less or equal 0
 * @returns {number} Returns area of circle
*
* */

function calculateArea(radius) {
    if (radius <= 0) {
        throw new Error("radius should be greater than 0");
    } else return radius*radius*3.14
}