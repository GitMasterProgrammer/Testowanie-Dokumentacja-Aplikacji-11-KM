/**
 * @author Kacper Matuszak 5D
 * @param {number} num1 - The first number
 * @param {number} num2 - The second number
 *
 * @throws {Error} if num2 is 0
 * @returns {number} - Returns num1 / num2 operation
 * @example
 * const a = 20;
 * const b = 10;
 *
 * const res = divide(a, b);
 * console.log(res);
 * // Logs: 2
 *
 * */

function divide(num1, num2) {
    if(num2 === 0){
        throw new Error("Error dividing by 0")

    } else return num1 / num2;
}