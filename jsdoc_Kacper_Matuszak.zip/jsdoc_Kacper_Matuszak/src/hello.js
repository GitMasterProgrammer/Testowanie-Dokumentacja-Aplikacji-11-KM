/**
 * Funkcja witajaca usera
 * @author Kacper Matuszak 5D
 * @param {string} somebody - Imie
 * @returns {undefined} none
 * */

const sayHello = (somebody) => {
    alert(`Hello ${somebody}`);
};