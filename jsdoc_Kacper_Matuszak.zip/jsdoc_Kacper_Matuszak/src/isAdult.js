/**
 * @param {number} age - The age
 * @throws {Error} - If age is <= 0
 * @returns {boolean} - Returns true if age > 18 and false if its < 18
 * */

function isAdult(age){
    if (age <= 0){
        throw new Error('True age is required');
    } else return age < 18;
}